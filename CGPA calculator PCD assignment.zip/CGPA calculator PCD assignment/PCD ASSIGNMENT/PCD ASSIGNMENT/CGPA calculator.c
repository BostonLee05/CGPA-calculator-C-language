#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#pragma warning(disable:4996)
#define MAX_STUDENTS 2

//function declaration
void userLogin();
void student();
void staff();
int main();
void clearBuffer();

typedef struct {
    char studentName[30];
    char studentID[10];
    double cgpa;
    int totalHours;
} Student;

//global variable
Student students[MAX_STUDENTS];
int studentCount = 0;
int choice;

int main() {

    int exitProgram = 0;
    while (!exitProgram) {

        printf("--------------------------\n");
        printf("|________________________|\n");
        printf("||Welcome to Kolej Pasar||\n");
        printf("||GPA/CGPA calculator   ||\n");
        printf("|------------------------|\n");
        printf("|  ---------      -----  |\n");
        printf("|  | GPA   |      | + |  |\n");
        printf("|  ---------      -----  |\n");
        printf("|  ---------      -----  |\n");
        printf("|  | CGPA  |      | - |  |\n");
        printf("|  ---------      -----  |\n");
        printf("|  ---------      -----  |\n");
        printf("|  | GRADE |      | = |  |\n");
        printf("|  ---------      -----  |\n");
        printf("--------------------------\n");
        printf("\n");
        printf("\n");

        userLogin();

        printf("Press 0 to exit, 1 to continue > ");
        scanf("%d", &choice);
        clearBuffer();

        if (choice == 0) {
            printf("Exiting...\n");
            exitProgram = 1;
        }
    }
    return 0;

}

void userLogin() {

    int mode;

    printf("===============User Login===============\n");
    printf("           1.Student                    \n");
    printf("           2.Staff Administrator        \n");
    printf("           3.Exit                       \n");
    printf("========================================\n");
    printf("Enter User :");
    scanf("%d", &mode);

    switch (mode) {
    case 1:
        student();
        break;
    case 2:
        staff();
        break;
    case 3:
        printf("Exiting...\n");
        exit(0);
    default:
        printf("Sorry. Invalid. \n");
        break;
    }

}

void staff() {

    char staffName[30], staffId[12];
    int sem, courses, crdHours, hours, ttlHours = 0, alphabet;
    double points, ttlPoints = 0.0, grdPoints[] = { 4.00, 3.75, 3.50, 3.00, 2.75, 2.50, 2.00, 0.00 };
    char* grd[] = { "A", "A-", "B+", "B", "B-", "C+", "C", "F" }, letter[3];

    if (studentCount >= MAX_STUDENTS) {
        printf("Maximum students reached.\n");
        return;
    }

    printf("--------------------------\n");
    printf("|________________________|\n");
    printf("||You have Login to     ||\n");
    printf("||Staff Mode            ||\n");
    printf("|------------------------|\n");
    printf("|  ---------      -----  |\n");
    printf("|  | GPA   |      | + |  |\n");
    printf("|  ---------      -----  |\n");
    printf("|  ---------      -----  |\n");
    printf("|  | CGPA  |      | - |  |\n");
    printf("|  ---------      -----  |\n");
    printf("|  ---------      -----  |\n");
    printf("|  | GRADE |      | = |  |\n");
    printf("|  ---------      -----  |\n");
    printf("--------------------------\n");

    printf("Enter your staff ID    >");
    scanf("%s", staffId);
    clearBuffer();

    printf("Enter your Name        >");
    fgets(staffName, sizeof(staffName), stdin);
    strtok(staffName, "\n"); 

    printf("Enter a student name   >");
    fgets(students[studentCount].studentName, sizeof(students[studentCount].studentName), stdin);
    strtok(students[studentCount].studentName, "\n");

    printf("Enter the student's ID >");
    scanf("%s", students[studentCount].studentID);
    clearBuffer();

    printf("\n");


    for (int sem = 1; sem <= 3; sem++) {
        points = 0.0;  
        hours = 0;
        printf("\n****\n");
        printf("\nSemester %d\n", sem);
        printf("\n****\n");
        printf("================================================\n");

        for ( courses = 1; courses <= 2; courses++) {
            do {
                printf("|--------------------------------------------------------------------|\n");
                printf("| Letter grade for course %d (A, A-, B+, B, B-, C+, C, F): ", courses);
                scanf(" %2s", letter);
                printf("| Credit hours for course %d: ", courses);
                alphabet = scanf("%d", &crdHours);
                while (getchar() != '\n');
                printf("|--------------------------------------------------------------------|\n");
                for (int i = 0; letter[i]; i++) {
                    letter[i] = toupper(letter[i]);
                }
                clearBuffer();
            } while (strcmp(letter, "A") != 0 && strcmp(letter, "A-") != 0 && strcmp(letter, "B+") != 0 &&
                strcmp(letter, "B") != 0 && strcmp(letter, "B-") != 0 && strcmp(letter, "C+") != 0 &&
                strcmp(letter, "C") != 0 && strcmp(letter, "F") != 0 && (crdHours < 0 || alphabet != 1));


            for (int k = 0; k < 8; k++) {
                if (strcmp(letter, grd[k]) == 0) {
                    points += grdPoints[k] * crdHours;
                    hours += crdHours;
                    break;
                }
            }
            ttlPoints += points;
            ttlHours += hours;
        }

        double gpa = points / hours;

        printf("Total quality points for Semester %d     : %.2lf\n", sem, points);
        printf("Total credit hours for Semester %d       : %d\n", sem, hours);
        printf("GPA for Semester %d                      : %.2lf\n", sem, gpa);

  
    }

    students[studentCount].cgpa = ttlPoints / ttlHours;
    students[studentCount].totalHours = ttlHours;

    printf("Student Added: %s, %s\n", students[studentCount].studentName, students[studentCount].studentID);
    studentCount++;

    printf("Press 0 to exit, 1 to continue > ");
    scanf("%d", &choice);
    clearBuffer();

    if (choice == 0) {
        printf("Exiting...\n");
        exit(0);
    }
    else if (choice == 1) {
        printf("Back to UserLogin page...\n");
        userLogin();
    }

}

void student() {

    char studentName[30], studentID[7];

    printf("--------------------------\n");
    printf("|________________________|\n");
    printf("||You have Login to     ||\n");
    printf("||Student Mode          ||\n");
    printf("|------------------------|\n");
    printf("|  ---------      -----  |\n");
    printf("|  | GPA   |      | + |  |\n");
    printf("|  ---------      -----  |\n");
    printf("|  ---------      -----  |\n");
    printf("|  | CGPA  |      | - |  |\n");
    printf("|  ---------      -----  |\n");
    printf("|  ---------      -----  |\n");
    printf("|  | GRADE |      | = |  |\n");
    printf("|  ---------      -----  |\n");
    printf("--------------------------\n");

    clearBuffer();  
    printf("Enter a student name    >");
    fgets(studentName, sizeof(studentName), stdin);
    strtok(studentName, "\n");

    printf("Enter the student's ID  >");
    fgets(studentID, sizeof(studentID), stdin);
    strtok(studentID, "\n");

    for (int j = 0; j < studentCount; j++) {
        printf("Comparing %s with %s and %s with %s\n", students[j].studentName, studentName, students[j].studentID, studentID);

        if (strcmp(students[j].studentName, studentName) == 0 && strcmp(students[j].studentID, studentID) == 0) {

            printf("\nCongratulations %s!!", studentName);
            printf("\nYour Overall CGPA %.2lf\n", students[j].cgpa);
            printf("\n");

            if (students[j].totalHours > 21) {
                printf("%s total credit hours is %d , eligible to graduate.\n", students[j].studentName, students[j].totalHours);
            }
            else {
                printf("%s total credit hours is %d, not yet eligible to graduate.\n", students[j].studentName, students[j].totalHours);
                printf("You must acheive at least 21 total credit hours to graduate.\n");
            }

            printf("-----------------------------------\n");
            printf("|           Scholarship           |\n");
            printf("|---------------------------------|\n");
            printf("|   Grade Point   |  Discount(%%) |\n");
            printf("|-----------------|---------------|\n");
            printf("|      4.00       |      100      |\n");
            printf("|-----------------|---------------|\n");
            printf("|      3.75       |       75      |\n");
            printf("|-----------------|---------------|\n");
            printf("|      3.50       |       50      |\n");
            printf("|-----------------|---------------|\n");
            printf("|      3.00       |       25      |\n");
            printf("-----------------------------------\n");

            if (students[j].cgpa >= 3.99 && students[j].cgpa <= 4.00)
                printf("Congrats, You've got a (100%%) of scolarship.\n");

            else if (students[j].cgpa >= 3.75 && students[j].cgpa < 4.00)
                printf("Congrats, You've got a (75%%) of scolarship.\n");
       
            else if (students[j].cgpa >= 3.50 && students[j].cgpa < 3.75)
                printf("Congrats, You've got a (50%%) of scolarship.\n");

            else if (students[j].cgpa >= 3.00 && students[j].cgpa < 3.50)
                printf("Congrats, You've got a (25%%) of scolarship.\n");

            else if (students[j].cgpa < 3.00)
                printf("Sorry, You do not get any scholarship.\n");

            return;
        }
    }
    printf("Student not found.\n");

}

void clearBuffer() {
    while (getchar() != '\n');
}


